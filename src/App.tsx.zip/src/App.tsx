import React, { useCallback, useEffect, useRef, useState } from "react";
import { useAuth }    from "./context/AuthContext";
import { useTheme }   from "./context/ThemeContext";
import { useSessionLog } from "./context/SessionLogContext";

import LoginPage        from "./components/Auth/LoginPage";
import Dashboard        from "./components/Dashboard/Dashboard";
import ModuleDashboard  from "./components/ModuleDashboard/ModuleDashboard";
import TestExecution    from "./components/TestExecution/TestExecution";
import TestReport       from "./components/TestReport/TestReport";
import AuditLog         from "./components/AuditLog/AuditLog";
import UsersPanel       from "./components/Users/UsersPanel";
import Sidebar          from "./components/Layout/Sidebar";
import MobileNav        from "./components/Layout/MobileNav";
import SessionManager   from "./components/UI/SessionManager";

// ── NEW: central query layer (replaces inline supabase.from calls) ─────────
import { fetchModules }  from "./lib/supabase/queries";
import supabase          from "./supabase";               // still needed for realtime channel
import type { Module }   from "./types";

type Page = "dashboard" | "module" | "execution" | "report" | "auditlog" | "users";

const App: React.FC = () => {
  const { isLoading: authLoading, isAuthenticated, user } = useAuth();
  const { theme }  = useTheme();
  const { log }    = useSessionLog();

  const [activePage,    setActivePage]    = useState<Page>("dashboard");
  const [activeModule,  setActiveModule]  = useState<string | null>(null);
  const [activeTest,    setActiveTest]    = useState<string | null>(null);
  const [modules,       setModules]       = useState<Module[]>([]);
  const [showInstall,   setShowInstall]   = useState(false);

  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  // ── PWA install prompt ─────────────────────────────────────────────────────
  useEffect(() => {
    const stashed = (window as any).installPrompt;
    if (stashed) { setShowInstall(true); return; }
    const handler = (e: Event) => {
      e.preventDefault();
      (window as any).installPrompt = e;
      setShowInstall(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    const installPrompt = (window as any).installPrompt;
    if (!installPrompt) return;
    installPrompt.prompt();
    const outcome = await installPrompt.userChoice;
    if (outcome.outcome === "accepted") setShowInstall(false);
  };

  const isAdmin = user?.role === "admin";

  // ── Log auth state ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!isAuthenticated) return;
    log("success", "auth", `Signed in as ${user?.email ?? "unknown"} (${user?.role ?? "?"})`);
  }, [isAuthenticated]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── CHANGED: use fetchModules() instead of inline supabase.from() ──────────
  const loadModules = useCallback(async () => {
    try {
      const data = await fetchModules();
      if (mountedRef.current) {
        setModules(data as Module[]);
        log("success", "query", `SELECT modules — ${data.length} rows`);
      }
    } catch (err: any) {
      log("error", "query", `SELECT modules failed — ${err.message}`, JSON.stringify(err));
      console.error("Error fetching modules:", err.message);
    }
  }, [log]);

  useEffect(() => {
    if (!isAuthenticated) return;
    loadModules();

    // Realtime subscription — supabase channel still used directly here
    const channel = supabase
      .channel("modules-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "modules" }, (payload) => {
        log("info", "realtime", `modules ${payload.eventType}`);
        loadModules();
      })
      .subscribe((status) => {
        log(
          status === "SUBSCRIBED" ? "success" : "warn",
          "realtime",
          `modules-realtime channel ${status}`
        );
      });

    return () => { supabase.removeChannel(channel); };
  }, [isAuthenticated]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Navigation ─────────────────────────────────────────────────────────────
  const handleNavigate = useCallback((page: string, moduleName?: string) => {
    log("info", "nav", `navigate → ${page}${moduleName ? ` (${moduleName})` : ""}`);
    if (page === "module" && moduleName) {
      setActiveModule(moduleName);
      setActivePage("module");
    } else if (page === "execution" && moduleName) {
      setActiveTest(moduleName);
      setActivePage("execution");
    } else {
      setActivePage(page as Page);
    }
  }, [log]);

  // ── Guards ─────────────────────────────────────────────────────────────────
  if (authLoading) return (
    <div className="grad-bg min-h-screen flex items-center justify-center">
      <div className="w-10 h-10 rounded-full border-4 border-c-brand border-t-transparent animate-spin" />
    </div>
  );

  if (!isAuthenticated) return <LoginPage />;

  // ── Page rendering ─────────────────────────────────────────────────────────
  const renderPage = () => {
    switch (activePage) {
      case "dashboard":  return <Dashboard onNavigate={handleNavigate} />;
      case "module":     return <ModuleDashboard moduleName={activeModule ?? ""} onNavigate={handleNavigate} />;
      case "execution":  return <TestExecution   testName={activeTest ?? ""}     onBack={() => setActivePage("module")} />;
      case "report":     return <TestReport />;
      case "auditlog":   return <AuditLog />;
      case "users":      return <UsersPanel />;
      default:           return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className={`min-h-screen flex ${theme}`}>
      <SessionManager />

      {/* Desktop sidebar */}
      <div className="hidden md:flex">
        <Sidebar
          activePage={activePage}
          onNavigate={handleNavigate}
          modules={modules}
        />
      </div>

      {/* Main content */}
      <main className="flex-1 flex flex-col min-h-screen overflow-y-auto">
        {renderPage()}
      </main>

      {/* Mobile bottom nav */}
      <MobileNav activePage={activePage} onNavigate={handleNavigate} />

      {/* PWA install banner */}
      {showInstall && (
        <div className="fixed bottom-20 md:bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-80
          bg-bg-surface border border-[var(--border-color)] rounded-2xl px-4 py-3
          flex items-center gap-3 shadow-2xl z-50">
          <div className="flex-1">
            <p className="text-sm font-semibold text-t-primary">Install TestPro</p>
            <p className="text-xs text-t-muted">Add to home screen for best experience</p>
          </div>
          <button onClick={handleInstall} className="btn-primary text-xs px-3 py-1.5">Install</button>
          <button onClick={() => setShowInstall(false)} className="text-t-muted hover:text-t-primary text-lg">✕</button>
        </div>
      )}
    </div>
  );
};

export default App;
